--
-- PostgreSQL database dump
--

\restrict fLVNChkowXGlripgm2LY0NN3K6YwNGS3Sua9ge3BIxgVXB2Yo55Av5og46sRNBh

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: admit_patient(integer, integer, integer, text); Type: FUNCTION; Schema: public; Owner: aidai
--

CREATE FUNCTION public.admit_patient(p_patient_id integer, p_room_id integer, p_doctor_id integer, p_reason text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_admission_id INTEGER;
BEGIN
    -- Check if room is available
    IF NOT EXISTS (SELECT 1 FROM rooms WHERE room_id = p_room_id AND is_available = true) THEN
        RETURN 'ERROR: Room is not available!';
    END IF;
    
    -- Create admission record
    INSERT INTO admissions (
        patient_id, room_id, doctor_id, 
        admission_reason, status
    ) VALUES (
        p_patient_id, p_room_id, p_doctor_id,
        p_reason, 'Active'
    ) RETURNING admission_id INTO v_admission_id;
    
    -- Mark room as unavailable
    UPDATE rooms SET is_available = false WHERE room_id = p_room_id;
    
    -- Create initial bill
    INSERT INTO bills (patient_id, admission_id, due_date, payment_status)
    VALUES (p_patient_id, v_admission_id, CURRENT_DATE + INTERVAL '30 days', 'Unpaid');
    
    RETURN 'SUCCESS: Patient admitted! Admission ID = ' || v_admission_id;
END;
$$;


ALTER FUNCTION public.admit_patient(p_patient_id integer, p_room_id integer, p_doctor_id integer, p_reason text) OWNER TO aidai;

--
-- Name: book_appointment(integer, integer, date, time without time zone, text); Type: FUNCTION; Schema: public; Owner: aidai
--

CREATE FUNCTION public.book_appointment(p_patient_id integer, p_doctor_id integer, p_appointment_date date, p_appointment_time time without time zone, p_reason text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_conflict_count INTEGER;
    v_appointment_id INTEGER;
BEGIN
    -- Check for time slot conflicts
    SELECT COUNT(*) INTO v_conflict_count
    FROM appointments
    WHERE doctor_id = p_doctor_id
        AND appointment_date = p_appointment_date
        AND appointment_time = p_appointment_time
        AND status != 'Cancelled';
    
    IF v_conflict_count > 0 THEN
        RETURN 'ERROR: Time slot is already booked!';
    END IF;
    
    -- Check if doctor is active
    IF NOT EXISTS (SELECT 1 FROM doctors WHERE doctor_id = p_doctor_id AND is_active = true) THEN
        RETURN 'ERROR: Doctor is not available!';
    END IF;
    
    -- Insert the appointment
    INSERT INTO appointments (
        patient_id, doctor_id, appointment_date, 
        appointment_time, status, reason
    ) VALUES (
        p_patient_id, p_doctor_id, p_appointment_date,
        p_appointment_time, 'Scheduled', p_reason
    ) RETURNING appointment_id INTO v_appointment_id;
    
    RETURN 'SUCCESS: Appointment booked! ID = ' || v_appointment_id;
END;
$$;


ALTER FUNCTION public.book_appointment(p_patient_id integer, p_doctor_id integer, p_appointment_date date, p_appointment_time time without time zone, p_reason text) OWNER TO aidai;

--
-- Name: discharge_patient(integer, integer); Type: FUNCTION; Schema: public; Owner: aidai
--

CREATE FUNCTION public.discharge_patient(p_admission_id integer, p_days_stayed integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_room_id INTEGER;
    v_daily_rate DECIMAL;
    v_total DECIMAL;
    v_bill_id INTEGER;
BEGIN
    -- Check if admission exists and is active
    IF NOT EXISTS (SELECT 1 FROM admissions WHERE admission_id = p_admission_id AND status = 'Active') THEN
        RETURN 'ERROR: No active admission found!';
    END IF;
    
    -- Get room info
    SELECT room_id INTO v_room_id FROM admissions WHERE admission_id = p_admission_id;
    SELECT daily_rate INTO v_daily_rate FROM rooms WHERE room_id = v_room_id;
    
    v_total := v_daily_rate * p_days_stayed;
    
    -- Update admission
    UPDATE admissions 
    SET discharge_date = CURRENT_TIMESTAMP, 
        status = 'Discharged',
        discharge_summary = 'Patient discharged after ' || p_days_stayed || ' days.'
    WHERE admission_id = p_admission_id;
    
    -- Free the room
    UPDATE rooms SET is_available = true WHERE room_id = v_room_id;
    
    -- Update bill
    SELECT bill_id INTO v_bill_id FROM bills WHERE admission_id = p_admission_id;
    
    INSERT INTO bill_items (bill_id, description, amount, item_type)
    VALUES (v_bill_id, 'Room charge for ' || p_days_stayed || ' days', v_total, 'Room');
    
    UPDATE bills 
    SET total_amount = (SELECT COALESCE(SUM(amount), 0) FROM bill_items WHERE bill_id = v_bill_id),
        balance = (SELECT COALESCE(SUM(amount), 0) FROM bill_items WHERE bill_id = v_bill_id)
    WHERE bill_id = v_bill_id;
    
    RETURN 'SUCCESS: Patient discharged! Total charge: $' || v_total;
END;
$_$;


ALTER FUNCTION public.discharge_patient(p_admission_id integer, p_days_stayed integer) OWNER TO aidai;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admissions; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.admissions (
    admission_id integer NOT NULL,
    patient_id integer NOT NULL,
    room_id integer NOT NULL,
    doctor_id integer NOT NULL,
    admission_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharge_date timestamp without time zone,
    admission_reason text,
    discharge_summary text,
    status character varying(20),
    CONSTRAINT admissions_status_check CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'Discharged'::character varying, 'Transferred'::character varying])::text[])))
);


ALTER TABLE public.admissions OWNER TO aidai;

--
-- Name: admissions_admission_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.admissions_admission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admissions_admission_id_seq OWNER TO aidai;

--
-- Name: admissions_admission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.admissions_admission_id_seq OWNED BY public.admissions.admission_id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.appointments (
    appointment_id integer NOT NULL,
    patient_id integer NOT NULL,
    doctor_id integer NOT NULL,
    appointment_date date NOT NULL,
    appointment_time time without time zone NOT NULL,
    status character varying(20),
    reason text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT appointments_status_check CHECK (((status)::text = ANY ((ARRAY['Scheduled'::character varying, 'Completed'::character varying, 'Cancelled'::character varying, 'No Show'::character varying])::text[])))
);


ALTER TABLE public.appointments OWNER TO aidai;

--
-- Name: doctors; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.doctors (
    doctor_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    phone character varying(20),
    specialization character varying(100),
    license_number character varying(50) NOT NULL,
    department_id integer,
    hire_date date NOT NULL,
    salary numeric(10,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctors OWNER TO aidai;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.patients (
    patient_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    date_of_birth date NOT NULL,
    gender character(1),
    email character varying(100),
    phone character varying(20) NOT NULL,
    address text,
    emergency_contact_name character varying(100),
    emergency_contact_phone character varying(20),
    blood_type character varying(3),
    insurance_provider character varying(100),
    insurance_id character varying(50),
    registration_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT patients_gender_check CHECK ((gender = ANY (ARRAY['M'::bpchar, 'F'::bpchar, 'O'::bpchar])))
);


ALTER TABLE public.patients OWNER TO aidai;

--
-- Name: appointment_summary; Type: VIEW; Schema: public; Owner: aidai
--

CREATE VIEW public.appointment_summary AS
 SELECT a.appointment_date,
    (((d.first_name)::text || ' '::text) || (d.last_name)::text) AS doctor_name,
    (((p.first_name)::text || ' '::text) || (p.last_name)::text) AS patient_name,
    a.appointment_time,
    a.status,
    a.reason
   FROM ((public.appointments a
     JOIN public.doctors d ON ((a.doctor_id = d.doctor_id)))
     JOIN public.patients p ON ((a.patient_id = p.patient_id)))
  ORDER BY a.appointment_date DESC;


ALTER TABLE public.appointment_summary OWNER TO aidai;

--
-- Name: appointments_appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.appointments_appointment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointments_appointment_id_seq OWNER TO aidai;

--
-- Name: appointments_appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.appointments_appointment_id_seq OWNED BY public.appointments.appointment_id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.audit_logs (
    log_id integer NOT NULL,
    table_name character varying(50),
    record_id integer,
    action character varying(10),
    old_data jsonb,
    new_data jsonb,
    changed_by integer,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO aidai;

--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.audit_logs_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_log_id_seq OWNER TO aidai;

--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.audit_logs_log_id_seq OWNED BY public.audit_logs.log_id;


--
-- Name: bill_items; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.bill_items (
    item_id integer NOT NULL,
    bill_id integer NOT NULL,
    description character varying(255),
    amount numeric(10,2),
    item_type character varying(50),
    CONSTRAINT bill_items_item_type_check CHECK (((item_type)::text = ANY ((ARRAY['Consultation'::character varying, 'Medicine'::character varying, 'Room'::character varying, 'Procedure'::character varying, 'Lab Test'::character varying, 'Other'::character varying])::text[])))
);


ALTER TABLE public.bill_items OWNER TO aidai;

--
-- Name: bill_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.bill_items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bill_items_item_id_seq OWNER TO aidai;

--
-- Name: bill_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.bill_items_item_id_seq OWNED BY public.bill_items.item_id;


--
-- Name: bills; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.bills (
    bill_id integer NOT NULL,
    patient_id integer NOT NULL,
    admission_id integer,
    bill_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    total_amount numeric(12,2),
    paid_amount numeric(12,2) DEFAULT 0,
    balance numeric(12,2),
    due_date date,
    payment_status character varying(20) DEFAULT 'Unpaid'::character varying,
    CONSTRAINT check_payment_status CHECK (((payment_status)::text = ANY ((ARRAY['Paid'::character varying, 'Partial'::character varying, 'Unpaid'::character varying, 'Overdue'::character varying])::text[])))
);


ALTER TABLE public.bills OWNER TO aidai;

--
-- Name: billing_summary; Type: VIEW; Schema: public; Owner: aidai
--

CREATE VIEW public.billing_summary AS
 SELECT b.bill_id,
    (((p.first_name)::text || ' '::text) || (p.last_name)::text) AS patient_name,
    b.bill_date,
    b.total_amount,
    b.paid_amount,
    b.balance,
    b.payment_status,
    b.due_date
   FROM (public.bills b
     JOIN public.patients p ON ((b.patient_id = p.patient_id)));


ALTER TABLE public.billing_summary OWNER TO aidai;

--
-- Name: bills_bill_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.bills_bill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bills_bill_id_seq OWNER TO aidai;

--
-- Name: bills_bill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.bills_bill_id_seq OWNED BY public.bills.bill_id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.rooms (
    room_id integer NOT NULL,
    room_number character varying(10) NOT NULL,
    room_type character varying(20),
    floor_number integer,
    is_available boolean DEFAULT true,
    daily_rate numeric(10,2),
    department_id integer,
    CONSTRAINT rooms_room_type_check CHECK (((room_type)::text = ANY ((ARRAY['General'::character varying, 'Private'::character varying, 'ICU'::character varying, 'Emergency'::character varying, 'Surgery'::character varying])::text[])))
);


ALTER TABLE public.rooms OWNER TO aidai;

--
-- Name: current_admissions; Type: VIEW; Schema: public; Owner: aidai
--

CREATE VIEW public.current_admissions AS
 SELECT ad.admission_id,
    (((p.first_name)::text || ' '::text) || (p.last_name)::text) AS patient_name,
    r.room_number,
    r.room_type,
    (((d.first_name)::text || ' '::text) || (d.last_name)::text) AS doctor_name,
    ad.admission_date,
    ad.admission_reason,
    ad.status
   FROM (((public.admissions ad
     JOIN public.patients p ON ((ad.patient_id = p.patient_id)))
     JOIN public.rooms r ON ((ad.room_id = r.room_id)))
     JOIN public.doctors d ON ((ad.doctor_id = d.doctor_id)))
  WHERE ((ad.status)::text = 'Active'::text);


ALTER TABLE public.current_admissions OWNER TO aidai;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.departments (
    department_id integer NOT NULL,
    department_name character varying(100) NOT NULL,
    floor_number integer,
    phone_extension character varying(15),
    head_doctor_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO aidai;

--
-- Name: departments_department_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.departments_department_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_department_id_seq OWNER TO aidai;

--
-- Name: departments_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.departments_department_id_seq OWNED BY public.departments.department_id;


--
-- Name: doctor_performance; Type: VIEW; Schema: public; Owner: aidai
--

CREATE VIEW public.doctor_performance AS
SELECT
    NULL::integer AS doctor_id,
    NULL::text AS doctor_name,
    NULL::character varying(100) AS specialization,
    NULL::character varying(100) AS department_name,
    NULL::bigint AS total_appointments,
    NULL::bigint AS unique_patients,
    NULL::numeric AS completion_rate_pct;


ALTER TABLE public.doctor_performance OWNER TO aidai;

--
-- Name: doctors_doctor_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.doctors_doctor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.doctors_doctor_id_seq OWNER TO aidai;

--
-- Name: doctors_doctor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.doctors_doctor_id_seq OWNED BY public.doctors.doctor_id;


--
-- Name: lab_tests; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.lab_tests (
    test_id integer NOT NULL,
    patient_id integer NOT NULL,
    doctor_id integer NOT NULL,
    test_name character varying(200) NOT NULL,
    test_category character varying(100),
    ordered_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_date timestamp without time zone,
    results text,
    is_abnormal boolean DEFAULT false,
    cost numeric(10,2),
    status character varying(20) DEFAULT 'Ordered'::character varying,
    CONSTRAINT check_test_status CHECK (((status)::text = ANY ((ARRAY['Ordered'::character varying, 'In Progress'::character varying, 'Completed'::character varying, 'Cancelled'::character varying])::text[])))
);


ALTER TABLE public.lab_tests OWNER TO aidai;

--
-- Name: lab_test_summary; Type: VIEW; Schema: public; Owner: aidai
--

CREATE VIEW public.lab_test_summary AS
 SELECT lt.test_id,
    (((p.first_name)::text || ' '::text) || (p.last_name)::text) AS patient_name,
    lt.test_name,
    lt.test_category,
    lt.status,
    lt.ordered_date,
    lt.completed_date,
    lt.cost
   FROM (public.lab_tests lt
     JOIN public.patients p ON ((lt.patient_id = p.patient_id)))
  ORDER BY lt.ordered_date DESC;


ALTER TABLE public.lab_test_summary OWNER TO aidai;

--
-- Name: lab_tests_test_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.lab_tests_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lab_tests_test_id_seq OWNER TO aidai;

--
-- Name: lab_tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.lab_tests_test_id_seq OWNED BY public.lab_tests.test_id;


--
-- Name: medical_records; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.medical_records (
    record_id integer NOT NULL,
    patient_id integer NOT NULL,
    doctor_id integer NOT NULL,
    appointment_id integer,
    diagnosis text,
    symptoms text,
    treatment_plan text,
    notes text,
    record_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.medical_records OWNER TO aidai;

--
-- Name: medical_records_record_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.medical_records_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.medical_records_record_id_seq OWNER TO aidai;

--
-- Name: medical_records_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.medical_records_record_id_seq OWNED BY public.medical_records.record_id;


--
-- Name: patient_summary; Type: VIEW; Schema: public; Owner: aidai
--

CREATE VIEW public.patient_summary AS
SELECT
    NULL::integer AS patient_id,
    NULL::text AS patient_name,
    NULL::numeric AS age,
    NULL::character varying(3) AS blood_type,
    NULL::character varying(100) AS insurance_provider,
    NULL::bigint AS total_appointments,
    NULL::bigint AS total_admissions;


ALTER TABLE public.patient_summary OWNER TO aidai;

--
-- Name: patients_patient_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.patients_patient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patients_patient_id_seq OWNER TO aidai;

--
-- Name: patients_patient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.patients_patient_id_seq OWNED BY public.patients.patient_id;


--
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.prescriptions (
    prescription_id integer NOT NULL,
    record_id integer NOT NULL,
    medication_name character varying(200) NOT NULL,
    dosage character varying(100),
    frequency character varying(100),
    duration character varying(100),
    notes text,
    prescribed_date date DEFAULT CURRENT_DATE,
    is_active boolean DEFAULT true
);


ALTER TABLE public.prescriptions OWNER TO aidai;

--
-- Name: prescriptions_prescription_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.prescriptions_prescription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prescriptions_prescription_id_seq OWNER TO aidai;

--
-- Name: prescriptions_prescription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.prescriptions_prescription_id_seq OWNED BY public.prescriptions.prescription_id;


--
-- Name: rooms_room_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.rooms_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rooms_room_id_seq OWNER TO aidai;

--
-- Name: rooms_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.rooms_room_id_seq OWNED BY public.rooms.room_id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.staff (
    staff_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    phone character varying(20),
    "position" character varying(100),
    department_id integer,
    hire_date date,
    salary numeric(10,2),
    shift character varying(20),
    is_active boolean DEFAULT true,
    CONSTRAINT staff_shift_check CHECK (((shift)::text = ANY ((ARRAY['Morning'::character varying, 'Evening'::character varying, 'Night'::character varying])::text[])))
);


ALTER TABLE public.staff OWNER TO aidai;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.staff_staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_staff_id_seq OWNER TO aidai;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.staff_staff_id_seq OWNED BY public.staff.staff_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: aidai
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20),
    associated_id integer,
    is_active boolean DEFAULT true,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['Admin'::character varying, 'Doctor'::character varying, 'Nurse'::character varying, 'Receptionist'::character varying, 'Patient'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO aidai;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: aidai
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO aidai;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aidai
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: admissions admission_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.admissions ALTER COLUMN admission_id SET DEFAULT nextval('public.admissions_admission_id_seq'::regclass);


--
-- Name: appointments appointment_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.appointments ALTER COLUMN appointment_id SET DEFAULT nextval('public.appointments_appointment_id_seq'::regclass);


--
-- Name: audit_logs log_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN log_id SET DEFAULT nextval('public.audit_logs_log_id_seq'::regclass);


--
-- Name: bill_items item_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.bill_items ALTER COLUMN item_id SET DEFAULT nextval('public.bill_items_item_id_seq'::regclass);


--
-- Name: bills bill_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.bills ALTER COLUMN bill_id SET DEFAULT nextval('public.bills_bill_id_seq'::regclass);


--
-- Name: departments department_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.departments ALTER COLUMN department_id SET DEFAULT nextval('public.departments_department_id_seq'::regclass);


--
-- Name: doctors doctor_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.doctors ALTER COLUMN doctor_id SET DEFAULT nextval('public.doctors_doctor_id_seq'::regclass);


--
-- Name: lab_tests test_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.lab_tests ALTER COLUMN test_id SET DEFAULT nextval('public.lab_tests_test_id_seq'::regclass);


--
-- Name: medical_records record_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.medical_records ALTER COLUMN record_id SET DEFAULT nextval('public.medical_records_record_id_seq'::regclass);


--
-- Name: patients patient_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.patients ALTER COLUMN patient_id SET DEFAULT nextval('public.patients_patient_id_seq'::regclass);


--
-- Name: prescriptions prescription_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.prescriptions ALTER COLUMN prescription_id SET DEFAULT nextval('public.prescriptions_prescription_id_seq'::regclass);


--
-- Name: rooms room_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.rooms ALTER COLUMN room_id SET DEFAULT nextval('public.rooms_room_id_seq'::regclass);


--
-- Name: staff staff_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.staff ALTER COLUMN staff_id SET DEFAULT nextval('public.staff_staff_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: admissions; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.admissions (admission_id, patient_id, room_id, doctor_id, admission_date, discharge_date, admission_reason, discharge_summary, status) FROM stdin;
1	4	1	5	2026-05-09 20:55:43.371902	2026-05-09 20:55:43.377921	Severe dehydration	Patient discharged after 3 days.	Discharged
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.appointments (appointment_id, patient_id, doctor_id, appointment_date, appointment_time, status, reason, notes, created_at) FROM stdin;
1	1	1	2024-01-20	09:00:00	Completed	Annual heart checkup	\N	2026-05-09 20:48:20.640797
2	1	1	2024-03-15	10:00:00	Scheduled	Follow-up	\N	2026-05-09 20:48:20.640797
3	2	2	2024-01-21	11:00:00	Completed	Migraine consultation	\N	2026-05-09 20:48:20.640797
4	3	4	2024-01-22	14:00:00	Cancelled	Flu symptoms	\N	2026-05-09 20:48:20.640797
5	4	3	2024-02-10	09:30:00	Scheduled	Child wellness check	\N	2026-05-09 20:48:20.640797
6	5	5	2024-02-12	15:00:00	Scheduled	Chest pain	\N	2026-05-09 20:48:20.640797
7	2	1	2024-02-15	11:00:00	Scheduled	Heart palpitations	\N	2026-05-09 20:48:20.640797
8	3	5	2024-03-01	08:00:00	Scheduled	Emergency follow-up	\N	2026-05-09 20:48:20.640797
9	3	1	2024-04-10	14:00:00	Scheduled	Chest pain follow-up	\N	2026-05-09 20:55:43.35888
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.audit_logs (log_id, table_name, record_id, action, old_data, new_data, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: bill_items; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.bill_items (item_id, bill_id, description, amount, item_type) FROM stdin;
1	1	Room charge for 3 days	1500.00	Room
\.


--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.bills (bill_id, patient_id, admission_id, bill_date, total_amount, paid_amount, balance, due_date, payment_status) FROM stdin;
1	4	1	2026-05-09 20:55:43.371902	1500.00	0.00	1500.00	2026-06-08	Unpaid
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.departments (department_id, department_name, floor_number, phone_extension, head_doctor_id, created_at, updated_at) FROM stdin;
1	Cardiology	1	1001	1	2026-05-09 20:48:20.630899	2026-05-09 20:48:20.630899
2	Neurology	2	1002	2	2026-05-09 20:48:20.630899	2026-05-09 20:48:20.630899
3	Pediatrics	3	1003	3	2026-05-09 20:48:20.630899	2026-05-09 20:48:20.630899
4	Orthopedics	1	1004	4	2026-05-09 20:48:20.630899	2026-05-09 20:48:20.630899
5	Emergency	1	1005	5	2026-05-09 20:48:20.630899	2026-05-09 20:48:20.630899
\.


--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.doctors (doctor_id, first_name, last_name, email, phone, specialization, license_number, department_id, hire_date, salary, is_active, created_at) FROM stdin;
1	John	Smith	john.smith@hospital.com	555-0101	Cardiologist	MED001	1	2020-01-15	250000.00	t	2026-05-09 20:48:20.633631
2	Sarah	Johnson	sarah.johnson@hospital.com	555-0102	Neurologist	MED002	2	2019-03-20	240000.00	t	2026-05-09 20:48:20.633631
3	Michael	Brown	michael.brown@hospital.com	555-0103	Pediatrician	MED003	3	2021-06-01	200000.00	t	2026-05-09 20:48:20.633631
4	Emily	Davis	emily.davis@hospital.com	555-0104	Orthopedic Surgeon	MED004	4	2018-09-10	280000.00	t	2026-05-09 20:48:20.633631
5	David	Wilson	david.wilson@hospital.com	555-0105	Emergency Medicine	MED005	5	2020-11-15	260000.00	t	2026-05-09 20:48:20.633631
\.


--
-- Data for Name: lab_tests; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.lab_tests (test_id, patient_id, doctor_id, test_name, test_category, ordered_date, completed_date, results, is_abnormal, cost, status) FROM stdin;
1	1	1	Complete Blood Count	Hematology	2026-05-09 20:48:20.647107	\N	\N	f	150.00	Completed
2	1	1	Lipid Panel	Chemistry	2026-05-09 20:48:20.647107	\N	\N	f	200.00	Completed
3	2	2	MRI Brain	Radiology	2026-05-09 20:48:20.647107	\N	\N	f	3000.00	Ordered
4	5	5	Chest X-Ray	Radiology	2026-05-09 20:48:20.647107	\N	\N	f	500.00	Ordered
5	3	4	Rapid Flu Test	Microbiology	2026-05-09 20:48:20.647107	\N	\N	f	100.00	Completed
\.


--
-- Data for Name: medical_records; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.medical_records (record_id, patient_id, doctor_id, appointment_id, diagnosis, symptoms, treatment_plan, notes, record_date) FROM stdin;
1	1	1	1	Mild hypertension	High blood pressure, occasional headaches	Prescribed beta blockers, recommend low-sodium diet	\N	2026-05-09 20:48:20.644291
2	2	2	3	Chronic migraine	Severe headaches, light sensitivity	Prescribed sumatriptan, follow up in 2 months	\N	2026-05-09 20:48:20.644291
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.patients (patient_id, first_name, last_name, date_of_birth, gender, email, phone, address, emergency_contact_name, emergency_contact_phone, blood_type, insurance_provider, insurance_id, registration_date) FROM stdin;
1	Alice	Williams	1985-05-15	F	alice.w@email.com	555-0201	123 Main St, City	Bob Williams	555-0202	A+	Blue Cross	BC123456	2026-05-09 20:48:20.636994
2	Robert	Miller	1990-08-20	M	robert.m@email.com	555-0203	456 Oak Ave, City	Mary Miller	555-0204	O-	Aetna	AE789012	2026-05-09 20:48:20.636994
3	Jennifer	Garcia	1975-12-10	F	jennifer.g@email.com	555-0205	789 Pine Rd, City	Carlos Garcia	555-0206	B+	United	UN345678	2026-05-09 20:48:20.636994
4	James	Lee	2000-03-25	M	james.l@email.com	555-0207	321 Elm St, City	Lisa Lee	555-0208	AB+	Cigna	CI901234	2026-05-09 20:48:20.636994
5	Maria	Lopez	1988-07-30	F	maria.l@email.com	555-0209	654 Maple Dr, City	Jose Lopez	555-0210	A-	Blue Cross	BC567890	2026-05-09 20:48:20.636994
\.


--
-- Data for Name: prescriptions; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.prescriptions (prescription_id, record_id, medication_name, dosage, frequency, duration, notes, prescribed_date, is_active) FROM stdin;
1	1	Atenolol	50mg	Once daily	30 days	\N	2026-05-09	t
2	2	Sumatriptan	100mg	As needed	30 days	\N	2026-05-09	t
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.rooms (room_id, room_number, room_type, floor_number, is_available, daily_rate, department_id) FROM stdin;
2	102	General	1	t	500.00	1
3	201	Private	2	t	1500.00	2
4	202	Private	2	t	1500.00	2
5	ICU1	ICU	1	t	5000.00	5
6	ER1	Emergency	1	t	1000.00	5
7	OR1	Surgery	2	t	3000.00	4
1	101	General	1	t	500.00	1
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.staff (staff_id, first_name, last_name, email, phone, "position", department_id, hire_date, salary, shift, is_active) FROM stdin;
1	Patricia	Taylor	patricia.t@hospital.com	555-0301	Head Nurse	1	2019-05-10	80000.00	Morning	t
2	Kevin	Anderson	kevin.a@hospital.com	555-0302	Receptionist	1	2022-01-15	40000.00	Morning	t
3	Linda	Martinez	linda.m@hospital.com	555-0303	Lab Technician	5	2020-08-20	55000.00	Evening	t
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aidai
--

COPY public.users (user_id, username, password_hash, role, associated_id, is_active, last_login, created_at) FROM stdin;
1	admin	hashed_password_admin	Admin	\N	t	\N	2026-05-09 20:48:20.650103
2	dr.smith	hashed_password_smith	Doctor	1	t	\N	2026-05-09 20:48:20.650103
3	dr.johnson	hashed_password_johnson	Doctor	2	t	\N	2026-05-09 20:48:20.650103
4	nurse.taylor	hashed_password_taylor	Nurse	1	t	\N	2026-05-09 20:48:20.650103
5	alice.w	hashed_password_alice	Patient	1	t	\N	2026-05-09 20:48:20.650103
\.


--
-- Name: admissions_admission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.admissions_admission_id_seq', 1, true);


--
-- Name: appointments_appointment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.appointments_appointment_id_seq', 9, true);


--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.audit_logs_log_id_seq', 1, false);


--
-- Name: bill_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.bill_items_item_id_seq', 1, true);


--
-- Name: bills_bill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.bills_bill_id_seq', 1, true);


--
-- Name: departments_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.departments_department_id_seq', 5, true);


--
-- Name: doctors_doctor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.doctors_doctor_id_seq', 5, true);


--
-- Name: lab_tests_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.lab_tests_test_id_seq', 5, true);


--
-- Name: medical_records_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.medical_records_record_id_seq', 2, true);


--
-- Name: patients_patient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.patients_patient_id_seq', 5, true);


--
-- Name: prescriptions_prescription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.prescriptions_prescription_id_seq', 2, true);


--
-- Name: rooms_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.rooms_room_id_seq', 7, true);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 3, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aidai
--

SELECT pg_catalog.setval('public.users_user_id_seq', 5, true);


--
-- Name: admissions admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_pkey PRIMARY KEY (admission_id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (appointment_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (log_id);


--
-- Name: bill_items bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_pkey PRIMARY KEY (item_id);


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (bill_id);


--
-- Name: departments departments_department_name_key; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_department_name_key UNIQUE (department_name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_id);


--
-- Name: doctors doctors_email_key; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_email_key UNIQUE (email);


--
-- Name: doctors doctors_license_number_key; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_license_number_key UNIQUE (license_number);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (doctor_id);


--
-- Name: lab_tests lab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_pkey PRIMARY KEY (test_id);


--
-- Name: medical_records medical_records_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.medical_records
    ADD CONSTRAINT medical_records_pkey PRIMARY KEY (record_id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (patient_id);


--
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (prescription_id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (room_id);


--
-- Name: rooms rooms_room_number_key; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_room_number_key UNIQUE (room_number);


--
-- Name: staff staff_email_key; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_email_key UNIQUE (email);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: appointments unique_appointment; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT unique_appointment UNIQUE (doctor_id, appointment_date, appointment_time);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_admissions_patient; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_admissions_patient ON public.admissions USING btree (patient_id);


--
-- Name: idx_admissions_status; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_admissions_status ON public.admissions USING btree (status);


--
-- Name: idx_appointments_date; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_appointments_date ON public.appointments USING btree (appointment_date);


--
-- Name: idx_appointments_doctor; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_appointments_doctor ON public.appointments USING btree (doctor_id, appointment_date);


--
-- Name: idx_appointments_patient; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_appointments_patient ON public.appointments USING btree (patient_id);


--
-- Name: idx_appointments_status; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_appointments_status ON public.appointments USING btree (status);


--
-- Name: idx_bills_due_date; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_bills_due_date ON public.bills USING btree (due_date);


--
-- Name: idx_bills_patient; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_bills_patient ON public.bills USING btree (patient_id);


--
-- Name: idx_bills_status; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_bills_status ON public.bills USING btree (payment_status);


--
-- Name: idx_doctors_department; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_doctors_department ON public.doctors USING btree (department_id);


--
-- Name: idx_doctors_specialization; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_doctors_specialization ON public.doctors USING btree (specialization);


--
-- Name: idx_lab_tests_patient; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_lab_tests_patient ON public.lab_tests USING btree (patient_id);


--
-- Name: idx_lab_tests_status; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_lab_tests_status ON public.lab_tests USING btree (status);


--
-- Name: idx_medical_records_date; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_medical_records_date ON public.medical_records USING btree (record_date);


--
-- Name: idx_medical_records_patient; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_medical_records_patient ON public.medical_records USING btree (patient_id);


--
-- Name: idx_patients_name; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_patients_name ON public.patients USING btree (last_name, first_name);


--
-- Name: idx_patients_phone; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_patients_phone ON public.patients USING btree (phone);


--
-- Name: idx_prescriptions_active; Type: INDEX; Schema: public; Owner: aidai
--

CREATE INDEX idx_prescriptions_active ON public.prescriptions USING btree (is_active);


--
-- Name: doctor_performance _RETURN; Type: RULE; Schema: public; Owner: aidai
--

CREATE OR REPLACE VIEW public.doctor_performance AS
 SELECT d.doctor_id,
    (((d.first_name)::text || ' '::text) || (d.last_name)::text) AS doctor_name,
    d.specialization,
    dep.department_name,
    count(DISTINCT a.appointment_id) AS total_appointments,
    count(DISTINCT a.patient_id) AS unique_patients,
    round((avg(
        CASE
            WHEN ((a.status)::text = 'Completed'::text) THEN 1
            ELSE 0
        END) * (100)::numeric), 1) AS completion_rate_pct
   FROM ((public.doctors d
     JOIN public.departments dep ON ((d.department_id = dep.department_id)))
     LEFT JOIN public.appointments a ON ((d.doctor_id = a.doctor_id)))
  GROUP BY d.doctor_id, dep.department_name;


--
-- Name: patient_summary _RETURN; Type: RULE; Schema: public; Owner: aidai
--

CREATE OR REPLACE VIEW public.patient_summary AS
 SELECT p.patient_id,
    (((p.first_name)::text || ' '::text) || (p.last_name)::text) AS patient_name,
    EXTRACT(year FROM age((CURRENT_DATE)::timestamp with time zone, (p.date_of_birth)::timestamp with time zone)) AS age,
    p.blood_type,
    p.insurance_provider,
    count(DISTINCT a.appointment_id) AS total_appointments,
    count(DISTINCT ad.admission_id) AS total_admissions
   FROM ((public.patients p
     LEFT JOIN public.appointments a ON ((p.patient_id = a.patient_id)))
     LEFT JOIN public.admissions ad ON ((p.patient_id = ad.patient_id)))
  GROUP BY p.patient_id;


--
-- Name: admissions admissions_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(doctor_id);


--
-- Name: admissions admissions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(patient_id);


--
-- Name: admissions admissions_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(room_id);


--
-- Name: appointments appointments_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(doctor_id);


--
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(patient_id);


--
-- Name: audit_logs audit_logs_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(user_id);


--
-- Name: bill_items bill_items_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.bills(bill_id);


--
-- Name: bills bills_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.admissions(admission_id);


--
-- Name: bills bills_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(patient_id);


--
-- Name: doctors doctors_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(department_id);


--
-- Name: departments fk_head_doctor; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_head_doctor FOREIGN KEY (head_doctor_id) REFERENCES public.doctors(doctor_id);


--
-- Name: lab_tests lab_tests_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(doctor_id);


--
-- Name: lab_tests lab_tests_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(patient_id);


--
-- Name: medical_records medical_records_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.medical_records
    ADD CONSTRAINT medical_records_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(appointment_id);


--
-- Name: medical_records medical_records_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.medical_records
    ADD CONSTRAINT medical_records_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(doctor_id);


--
-- Name: medical_records medical_records_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.medical_records
    ADD CONSTRAINT medical_records_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(patient_id);


--
-- Name: prescriptions prescriptions_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_record_id_fkey FOREIGN KEY (record_id) REFERENCES public.medical_records(record_id);


--
-- Name: rooms rooms_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(department_id);


--
-- Name: staff staff_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aidai
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(department_id);


--
-- PostgreSQL database dump complete
--

\unrestrict fLVNChkowXGlripgm2LY0NN3K6YwNGS3Sua9ge3BIxgVXB2Yo55Av5og46sRNBh

